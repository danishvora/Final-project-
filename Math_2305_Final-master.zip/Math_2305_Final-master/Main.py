
from Algorithms.prims_algorithm import prims
#from Functions.graph_operations import graph_cost


#text = input("Please provide a graph to run the TSP on ")

#text = input("PLease provide a starting vertex ")
T = prims
print(f'Optimal Tree:', prims)

print('')

#print(f'Optimal cost: {graph_cost(G)}')